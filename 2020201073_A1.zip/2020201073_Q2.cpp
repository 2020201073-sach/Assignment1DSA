#include<iostream>
#include<string>
#include<cmath>
#include<bits/stdc++.h>
using namespace std;

class BigInt{
public:
	int *arr=new int[5000];
	string s;
	int len;
	void insert(){
		string s;
		cout<<"Enter your number:";
		cin>>s;
		len = s.length();
		for(int i=len-1,k=0;i>=0;i--,k++)
			arr[k] = s[i]-'0';
	}
	void insert_p(string s){//999
		len = s.length();
		for(int i=len-1,k=0;i>=0;i--,k++)
			arr[k] = s[i]-'0';
	}
	void show(){
		for(int i=len-1;i>=0;i--)
			cout<<arr[i];
		cout<<"\n";
	}

	BigInt addI(BigInt b){
		BigInt c;
		int carry=0;
		int aux_len = len>b.len?len:b.len;
		for(int i=0;i<aux_len;i++){
			c.arr[i] = arr[i]+b.arr[i]+carry;
			if(c.arr[i]>9){
				carry = c.arr[i]/10;
				c.arr[i]%=10;
			}
			else
				carry=0;
		}
		if(carry!=0){
			c.arr[aux_len]=carry;
			c.len = aux_len+1;
		}
		else
			c.len = aux_len;

		return c;

	}

	BigInt multiply_one_digit(int x){
		BigInt c;
		int carry=0;
		int aux_len = len;
		for(int i=0;i<aux_len;i++){
			c.arr[i] = x*arr[i] + carry;
			if(c.arr[i]>9){
				carry = c.arr[i]/10;
				c.arr[i]%=10;
			}
			else
				carry=0;
		}
		if(carry!=0){
			c.arr[aux_len]=carry;
			c.len = aux_len+1;
		}
		else
			c.len = aux_len;
		return c;
	}

	
};


BigInt multiply_multiple_digit(BigInt multiplicand, BigInt multiplier){
		BigInt c;
		BigInt end_res;

		int res[5000]={0};
		int k,carry=0,x;
		for(int i=0;i<multiplier.len;i++){
			c = multiplicand.multiply_one_digit(multiplier.arr[i]);
			k=c.len;
			for(int j=i,x=0;j<i+k;j++,x++){
				res[j]+= c.arr[x]+carry;
				if(res[j]>9){
					carry = res[j]/10;
					res[j]%=10;
				}
				else
					carry=0;
			}
			if(carry!=0)
				res[k+i]=carry;
		}

		k = multiplier.len+multiplicand.len;
		for(int i=0;i<k;i++)
			end_res.arr[i] = res[i];
		if(end_res.arr[k-1]==0)
			end_res.len = k-1;
		else
			end_res.len = k;
		return end_res;
	}

void facto(int n){
	BigInt b1,b2;
	b1.insert_p("1");
	string str;
	for(int i=1;i<=n;i++){
		str = to_string(i);
		b2.insert_p(str);
		b1 = multiply_multiple_digit(b1,b2);
	} 
	b1.show();
}

BigInt expo(BigInt b, int n){
	BigInt c;
	c.insert_p("1");
	while(n>0){
		if(n&1)
			c = multiply_multiple_digit(b,c);
		n=n>>1;
		b = multiply_multiple_digit(b,b);
	}
	return c;
}


BigInt diff(BigInt minuend,BigInt subtrahend){
	BigInt c;
	int aux_len=minuend.len;
	int borrow=0,j,i;
	for(i=0;i<aux_len;i++){
		j=i+1;
		if(minuend.arr[i]<subtrahend.arr[i]){
			borrow=10;
			while(!minuend.arr[j]){
				minuend.arr[j]=borrow-1;
				j++;
			}
			minuend.arr[j]--;
		}

		c.arr[i]= minuend.arr[i]+borrow- subtrahend.arr[i];
		borrow=0;

	}
	while(i>=0 && c.arr[i]==0)
		i--;
	c.len = i+1;
	if(c.len==0)
		c.len=1;
	return c;
}

bool eq(BigInt b1,BigInt b2){
	if(b1.len!=b2.len)
		return false;
	for(int i=0;i<b1.len;i++){
		if(b1.arr[i]!=b2.arr[i])
			return false;
	}
	return true;
}




BigInt div2(BigInt b1){
	BigInt Q;
	int i=0;
	int arr[4000]={0};
	int div_len= b1.len;
	int x = div_len-i-1,k=0;
	int temp= b1.arr[x];
	if(temp<2)
		temp = temp*10 + b1.arr[--x];
	while(x>=0){
		arr[k++]+= temp/2;
		temp = (temp%2)*10 + b1.arr[--x];
	}
	if(k==0)
		Q.len=1;
	else{
		Q.len=k;
		while((--k)>=0)
			Q.arr[i++]=arr[k];
	}

	return Q;

}


bool great(BigInt b1,BigInt b2){
	if(b1.len>b2.len)
		return true;
	if(b1.s > b2.s)
		return true;
	return false;
}

BigInt gcd(BigInt b1,BigInt b2){
	BigInt temp1,temp2;
	if(eq(b1,b2))
		return b1;
	if(b1.arr[0]==0 && b1.len==1)
		return b2;
	if(b2.arr[0]==0 && b2.len==1)
		return b1;
	if(b1.arr[0]%2==0){
		temp1 = div2(b1);
		if(b2.arr[0]%2==1)
			return gcd(temp1,b2);
		else{
			temp2 = div2(b2);
			BigInt temp3 = gcd(temp1,temp2);
			return temp3.multiply_one_digit(2);
		}
	}

	if(b2.arr[0]%2==0){
		temp2 = div2(b2);
		return gcd(b1,temp2);
	}

	if(great(b1,b2)){
		temp1 = diff(b1,b2);
		return gcd(temp1,b2);
	}
	else{
		temp2 = diff(b2,b1);
		return gcd(temp2,b1);
	}

}



int main(){
	BigInt b1,b2,b3;
	//b1.insert();
	//b1.insert_p("1000000000000000000000000000000000000000000");
	//b2.insert_p("10023320303453245356356346");
	//b3 = gcd(b2,b1);
	//b1.show();
	//cout<<b1.len;
	//b3 = multiply_multiple_digit(b1,b2);
	//b3 = expo(b1,999);
	//b3.show();
	//for(int i=10;i<21;i++)
		//facto(987);
	//b3.show();


	int Q,x;
	string s1,s2;
	int value;
	cin>>Q;
	while(Q--){
		cin>>x;
		switch(x){
			case 1:{ // exponentiation
				cin>>s1;
				cin>>value;
				b1.insert_p(s1);
				b3= expo(b1,value);
				b3.show();
				break;
			}
			case 2:{ //gcd
				cin>>s1>>s2;
				b1.insert_p(s1);
				b2.insert_p(s2);
				b3 = gcd(b1,b2);
				b3.show();
				break;
			}
			case 3:{ // factorial
				cin>>value;
				facto(value);
				break;
			}
			default: exit(0);
		}
	}

	return 0;
}