#include<iostream>
#include<string>
#include<cmath>
#include<stdlib.h>
#include<iomanip>
//#include<bits/stdc++.h>
using namespace std;

int prec(string x){
	if(x=="+" || x=="-")
		return 1;
	if(x=="*" || x=="/" || x=="%")
		return 2;
	return 0;
}

class Node{
public:
	string data;
	Node* next;
	Node(string x){
		data = x;
		next = NULL;
	}
};

// insert at beginning to the head

Node* insert_at_beg(Node* head, string ele){
	Node* new_Node = new Node(ele);
	if(head==NULL)
		return new_Node;
	new_Node->next = head;
	head = new_Node;
	return head;
}

Node* insert_at_end(Node* head, string ele){
	Node* new_Node = new Node(ele);
	if(head==NULL)
		return new_Node;
	Node* temp = head;
	while(temp->next!=NULL)
		temp = temp->next;
	temp->next = new_Node;
	return head;
}

class stack{
public:
	Node* top;
	stack(){
		top = NULL;
	}
	bool isEmpty(){
		if(top==NULL)
			return true;
		return false;
	}

	void push(string x){
		top = insert_at_beg(top,x);
	}
	string pop(){
		if(isEmpty()){
			cout<<"Empty stack\n";
			return "-1";
		}
		Node* temp = top;
		string k = temp->data;
		top = top->next;
		delete(temp);
		return k;
	}
};

Node* infixtopostfix(string in_exp,int length){
	stack postfix;
	Node* head = NULL;
	string s=" ";
	
	for(int i=0;i<length;i++){
		
		if(in_exp[i]>='0' && in_exp[i]<='9' || in_exp[i]=='.'){
			s.push_back(in_exp[i]);
			if(i==length-1)
				head = insert_at_end(head,s);
		}			
		
		else{
		    if(s!="")
			    head = insert_at_end(head,s);
			s="";
			s.push_back(in_exp[i]);
			if(postfix.top==NULL || in_exp[i]=='(')
				postfix.push(s);
			
			else if(s==")"){
				while(postfix.top->data!="(")
					head = insert_at_end(head,postfix.pop());
				postfix.pop();
			}
			else if(prec(s)> prec(postfix.top->data))
				postfix.push(s);
			else{
				while(postfix.top!=NULL && prec(s)<=prec(postfix.top->data))
					head=insert_at_end(head,postfix.pop());
				postfix.push(s);
			}
			s="";
		}
	}

	while(postfix.top!=NULL)
		head = insert_at_end(head,postfix.pop());

	return head;
}

void print_List(Node * temp){
	if(temp==NULL)
		cout<<" Empty linked list\n";
	else{
		while(temp->next!=NULL){
			cout<<temp->data;
			temp = temp->next;
		}
		cout<<temp->data<<'\n';
	}
}

bool Opr(string str){
	char x = str[0];
	if(x=='+' || x=='-' || x=='*' || x=='/' || x=='%')
		return true;
	return false;
}

double eval(double a,double b,string s){
	char x = s[0];
	switch(x){
		case '+': return a+b;
		case '-': return b-a;
		case '*': return b*a;
		case '/': return b/a;
		case '%': return (a-(int)a==0 && b-(int)b==0)?(int)b%(int)a:fmod(b,a);
		default: return -1;
	}
}

void postfix_evaluation(Node *postex){
	stack eval_stack;
	Node* temp = postex;
	int x;
	double y;

	while(temp!=NULL){
		if(!Opr(temp->data))
			eval_stack.push(temp->data);
		else{
			double a = stod(eval_stack.pop());
			double b = stod(eval_stack.pop());
			a = eval(a,b,temp->data);
			//if(a-(int)a==0){
			  //  x = (int)a;
			    //eval_stack.push(to_string(x));
		//	}
		//	else{
		//	    y = a;
			    eval_stack.push(to_string(a));
		//	}
		}
		temp= temp->next;
	}
	cout<<eval_stack.pop()<<"\n";
}

int main(){
	stack S;
	string infix_exp;
	cin>>infix_exp;
	int length = infix_exp.length();
	Node* postfix_head = infixtopostfix(infix_exp,length);
	//print_List(postfix_head);
	postfix_evaluation(postfix_head);
	return 0;
}
