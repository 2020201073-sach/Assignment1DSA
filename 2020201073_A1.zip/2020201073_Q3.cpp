#include<iostream>
using namespace std;
template <class T>

class Deque{
public:
	T* a;
	int frnt,rear;
	int size_d;
	int curr_len;

	Deque(){
		a = new T[16];
		size_d = 16;
		frnt=-1;
		rear=-1;
		curr_len=0;
	}

	Deque(int n,T x){
		a = new T[2*n];
		size_d = 2*n;
		for(int i=0;i<n;i++){
			a[i]=x;
		}
		frnt = 0;
		rear = n;
		curr_len=n;
	}

	void resize(int x,T d){
		if(x>curr_len){
			T *b = new T[2*x];
			int p = frnt,t=0;
			while((p%size_d)!=rear){
				b[t]=a[p%size_d];
				t++;
				p++;
			}
			while(t!=x){
				b[t]=d;
				t++;
			}
			delete[] a;
			a=b;
			frnt = 0;
			rear=t;
			curr_len=t;
			size_d = 2*x;
		}
		else{
			int extra = curr_len-x;
			while(extra){
				this->pop_back();
				extra--;
			}
			curr_len = x;
		}

	}

	string empty(){
		if(frnt==-1 && rear==-1)
			return "true";
		return "false";
	}

	T front(){
			return a[frnt];
	}

	T back(){
			return a[rear-1];
	}

	int size(){
		return curr_len;
	}

	void clear(){
		frnt=-1;
		rear=-1;
		//while((rear)%size_d!=frnt)
			//this->pop_front();
		delete[] a;
		this->a= new T[16];
		
	}

	void push_back(T x){
		curr_len++;
		if((rear+1)%size_d==frnt){
			T *b = new T[2*size_d];
			int p=frnt,t=0;
			while((p%size_d)!=rear){
				b[t]=a[p%size_d];
				t++;
				p++;
			}
			delete[] a;
			a = b;
			frnt=0;
			rear=t;
			a[rear]=x;
			size_d = 2*size_d;
		}
		
		else if(frnt==-1 && rear==-1){
			a[++rear] = x;
			frnt++;
		}

		else
			a[rear]=x;

		rear+=1;
	}


	void push_front(T x){
		curr_len++;
		if((rear+1)%size_d==frnt){
			T *b = new T[2*size_d];
			b[0]=x;
			int p=frnt,t=1;
			while((p%size_d)!=rear){
				b[t++]=a[p%size_d];
				p++;
			}
			delete[] a;
			//a = new int[2*size_d];
			//for(int i=0;i<t;i++)
			//	a[i]=b[i];
			a=b;
			frnt=0;
			rear = t;
			size_d = 2*size_d;
		}
		
		else if(frnt==-1){
			a[++rear] = x;
			rear++;
			frnt++;
		}

		else if(rear!=size_d-1){
			if(frnt==0){
				frnt = size_d-1;
				a[frnt]=x;
			}
			else
				a[--frnt]=x;
		}
	}

	void pop_front(){
		if(frnt==-1)
			return;
		else if((frnt+1)%size_d==rear){
			frnt=-1;
			rear = -1;
			curr_len--;
		}
		else{
			frnt = (frnt+1)%size_d;
			curr_len--;
		}
	}

	void pop_back(){
		if(frnt==-1)
			return;
		else if((frnt+1)%size_d==rear){
			frnt=-1;
			rear = -1;
			curr_len--;
		}
		else{
			rear = (rear-1)%size_d;
			curr_len--;
		}
	}

	void operator[](int n){
		if(n>=curr_len){
			cout<<"index out of bound\n";
			//return -1;
		}
		else if(frnt==-1){
			cout<<"Empty\n";//return -1;
		}
		else
			cout<<a[(frnt+n-1)%size_d]<<'\n';	//return a[(frnt+n-1)%size_d];
	}

	void display(){
		if(frnt==-1)
			cout<<"empty\n";
		else{
			int x=frnt;
			while(x%size_d!=rear)
				cout<<a[(x++)%size_d]<<"\t";
			cout<<'\n';
		}
	}
};


int main(){
	int Q;
	Deque<string> *d=NULL;
	cin>>Q;
	int z,n;
	string x;
	//z -> operation number, n->1st input to the function if required,x same as y
	while(Q--){
		cin>>z;

		switch(z){

			

			case 1: {
				cin>>x;
				d->push_front(x);
				d->display();
				break;
			}
			case 2: {
				d->pop_front();
				d->display();
				break;
			}
			case 3: {
				cin>>x;
				d->push_back(x);
				d->display();
				break;
			}
			case 4: {
				d->pop_back();
				d->display();
				break;
			}

			case 5: {
				if(d!=NULL)
					delete d;
				d = new Deque<string>();
					break;
			}
			
			case 6: {
				cin>>n>>x;
				if(d!=NULL)
					delete d;
				d = new Deque<string>(n,x);
				d->display();
				break;
			}
			
			case 7: {
				cout<<d->front()<<"\n";
				break;
			}
			case 8: {
				cout<<d->back()<<"\n";
				break;
			}
			case 9: {
				cout<<d->empty()<<"\n";
				break;
			}
			case 10: {
				cout<<d->size()<<"\n";
				break;
			}
			case 11: {
				cin>>n>>x;
				d->resize(n,x);
				d->display();
				break;
			}
			case 12: {
				d->clear();
				break;
			}
			case 13: {
				cin>>n;
				(*d)[n];
				break;
			}
			case 14:{
				d->display();
				break;
			}
			default: exit(0);
		}
	}



	return 0;
}